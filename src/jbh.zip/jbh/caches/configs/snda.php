<?php
return array(
'snda_status' => '0',
);
?>
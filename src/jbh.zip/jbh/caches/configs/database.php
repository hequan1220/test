<?php

return array (
	'default' => array (
		'hostname' => 'lv2fx6pg.2283lan.dnstoo.com:3306',
		'port' => 3306,
		'database' => 'zz-pi',
		'username' => 'zz-pi_f',
		'password' => 'tulip8650',
		'tablepre' => 'v9_',
		'charset' => 'utf8',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>
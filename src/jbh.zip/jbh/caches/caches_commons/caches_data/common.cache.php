<?php
return array (
  'admin_email' => 'phpcms@phpcms.cn',
  'adminaccessip' => '0',
  'maxloginfailedtimes' => '8',
  'maxiplockedtime' => '15',
  'minrefreshtime' => '2',
  'mail_type' => '1',
  'mail_server' => 'smtp.qq.com',
  'mail_port' => '25',
  'mail_user' => 'phpcms.cn@foxmail.com',
  'mail_auth' => '1',
  'mail_from' => 'phpcms.cn@foxmail.com',
  'mail_password' => '',
  'errorlog_size' => '20',
);
?>
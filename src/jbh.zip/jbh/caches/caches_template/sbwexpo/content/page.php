<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>﻿<?php include template("content","header"); ?>
	<div class="aboutcon center">
		<div class="about_left left">
		<h1><p><?php echo str_cut($CATEGORYS[$catid]['catname'],13);?></p></h1>
		<ul class="classify">
			<h2>相关分类</h2>
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=7a203e1113e620a3d33649a913a7f98f&action=category&num=15&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('order'=>'listorder ASC','limit'=>'15',));}?>
<ul><?php $n=1;if(is_array(subcat($catid))) foreach(subcat($catid) AS $r) { ?>
<li <?php if($catid==$r[catid]) { ?>class="selected"<?php } ?>><a href="<?php echo $CATEGORYS[$r['catid']]['url'];?>"><?php echo $CATEGORYS[$r['catid']]['catname'];?></a></li>
<?php $n++;}unset($n); ?>
</ul>
<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
		<h3><a href="/html/contact/">联系我们</a></h3>
		</div>
		<div class="about_right left">
			<h2><a href="<?php echo siteurl($siteid);?>">网站首页</a> > <?php echo catpos($catid);?> 正文</h2>
			<div class="info">
				<div class="info_title"><h4><?php echo $title;?></h4></div>
				<div class="info_time"></div>
				<?php if($description) { ?><div class="info_description">核心提示：<?php echo $description;?></div><?php } ?>
				<div class="info_content">
				<?php echo $content;?>
				</div>
				<div id="pages"><?php echo $pages;?></div>
				<div class="info_service">
						<span class="favorites"><a href="javascript:window.external.addFavorite(window.location.href,'新闻 ');">加入收藏</a></span>
						<span class="print"><a href="javascript:window.print();">打印本页</a></span>
						<span class="close"><a href="javascript:window.close();">关闭窗口</a></span>
						<span class="top"><a href="javascript:window.scrollTo(0,0);">返回顶部</a></span>
				</div>
			</div>
		</div>
	</div>	
</div>
<?php include template("content","footer"); ?>
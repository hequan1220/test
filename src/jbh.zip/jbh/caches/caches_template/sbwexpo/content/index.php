<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/jquery.sgallery.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/global.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/menu.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/JavaScript.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/scroll.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo CSS_PATH;?>sbwexpo/css/sbwexpo.css"/>
<style type="text/css" media="all">
.d1{width:100%;height:340px;height:auto;overflow:hidden;border:none;background-color:#FFF;position:relative;}
.loading{background-color:#FFF;color:#FFCC00;font-size:12px;height:560x;text-align:center;padding-top:30px;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:bold;}
.d2{width:100%;height:340px;overflow:hidden;}
.num_list{position:absolute;width:100%;left:0px;bottom:-1px;background-color:#000000;color:#FFFFFF;font-size:12px;padding:4px 0px;height:20px;overflow:hidden;}
.num_list span{display:inline-block;height:16px;padding-left:6px;}
img{border:0px;}
#fade_focus ul{display:none;}
.button{position:absolute; z-index:1000; right:0px; bottom:2px; font-size:13px; font-weight:bold; font-family:Arial, Helvetica, sans-serif;}
.b1,.b2{background-color:#666666;display:block;float:left;padding:2px 6px;margin-right:3px;color:#FFFFFF;text-decoration:none;cursor:pointer;}
#lovexin1,#lovexin2{width:100px;display:none}
.d2 img{border:none;}
.loading {width:1920px;margin:0 audio;}
</style>
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?><?php echo $SEO['site_title'];?></title>
</head>
<body>
<!------------head start-------------->

<div>
<div class="head">
  <div class="wrap fff">
	<div class="tips" id="announ">
        	<ul>
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=0c47352bd95f85c91cea75d8803b09ef&action=lists&catid=34&num=10&order=id+DESC&return=info\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$info = $content_tag->lists(array('catid'=>'34','order'=>'id DESC','limit'=>'10',));}?>
                <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?>
                	<li><a href="<?php echo $v['url'];?>" class="bright"  target="_blank" title="<?php echo $v['title'];?>"<?php echo title_style($v[style]);?>><?php echo str_cut($v['title'],100);?>     <span>【<?php echo date('Y-m-d',$v[inputtime]);?></span>】</a></li>
                <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
<script type="text/javascript">
$(function(){
	startmarquee('announ',28,1,400,4000);
})
</script>

     <div class="setup">
   		  <a href="#" id="sethomepage">设为首页</a> | 
          <a href="#" id="favorites">加入收藏</a>
     </div>
<div  style="clear:both" class="hdbg" >
<script language="javascript" src="<?php echo APP_PATH;?>index.php?m=poster&c=index&a=show_poster&id=11"></script>
</div>
       <div id="myslidemenu">
        	<ul class="nav">
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b43f1459ac702900c8d44c91a5e796dd&action=category&catid=0&num=25&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>'0','siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'25',));}?>
            <li class="home"><a href="/">首页</a></li>
            <?php $n=1; if(is_array($data)) foreach($data AS $k => $v) { ?>
        	<li><a href="<?php echo $v['url'];?>"><?php echo $v['catname'];?></a>
                  <ul id="jquerys_blue" style="background:#c40025;">
                  <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=050b6fa64652ce6258bc9e7d61f5b7cc&action=category&catid=%24k&num=10&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>$k,'siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'10',));}?>
                 <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>  <li><a href="<?php echo $r['url'];?>"><?php echo $r['catname'];?></a></li> <?php $n++;}unset($n); ?>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                  </ul>
            </li>
                        <?php $n++;}unset($n); ?>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        </ul>
        </div>
    </div>
  </div>
<!-------------head end-------------------->
<!---------------banner start---------------------->
<div class="rap">
<div id="fade_focus">
    <div class="loading">Loading...<br /><img src="<?php echo IMG_PATH;?>sbwexpo/images/logings.gif" width="100" height="100" /></div>
    <ul>
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a79df0c544b2e95049e47f7f683d9090&action=lists&catid=35&order=listorder+ASC&thumb=1&num=6&return=info\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$info = $content_tag->lists(array('catid'=>'35','order'=>'listorder ASC','thumb'=>'1','limit'=>'6',));}?>
             <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?>
      <li style="width:1920px;margin:0 auto;border:none;"><img src="<?php echo thumb($v[thumb],1920,340);?>" width="1920" height="340"  border="none"  nalt="<?php echo $v['title'];?>" /></li>
          <?php $n++;}unset($n); ?>
              <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
   
 </ul>
</div>

</div>
<!---------------banner end---------------------->

<div class="clear h8"></div>
<!---------------天气预报倒计时结束------------>
<div class="wrap">
<!--------------主体第一部分左边开始--------------->
	<div class="one_left">
<!--
    	<div class="video">
        	<h1>视频</h1>
            <embed src="http://player.youku.com/player.php/sid/XNjMyNTQwNTQ4/v.swf" allowFullScreen="true" quality="high" width="250" height="200" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed>        </div> -->
        <div class="organization" style="margin-top:0px;">
        	<h1>组织机构</h1>
        	<div class="organization_top">
        	</div>
            <div class="organization_center">
          <div class="seamless" style="height:290px;">
        <?php echo show_ad(1, 15);?>
</div>
</div>
              </div>
            <div class="organization_bottom">
        </div>
    </div>
  <!--------------主体第一部分左边结束--------------->
<!------------主体中间部分开始-------->
	<div class="one_center">
    	<div class="about">
        	<h1>展会概况</h1>
            <!--<img src="<?php echo IMG_PATH;?>sbwexpo/images/temp_about.jpg" />-->
			<script language="javascript" src="<?php echo APP_PATH;?>index.php?m=poster&c=index&a=show_poster&id=16"></script>
            <?php echo show_ad(1, 14);?>
        </div>
<script type="text/javascript">
function settab_zzjs(name,num,n){
 for(i=1;i<=n;i++){
  var menu=document.getElementById(name+i);
  var con=document.getElementById(name+"_"+"tabmenu"+i);
  menu.className=i==num?"hover":"";
    con.style.display=i==num?"block":"none";
 }
}
</script>
        <div class="news">
    	<div class="tabnav" id="tabmenu">
            <ul>
                <li><a href="#" class="hover" id="tabmenu1" onmouseover="settab_zzjs('tabmenu',1,2)">大会新闻</a></li>
                <li><a href="#" id="tabmenu2" onmouseover="settab_zzjs('tabmenu',2,2)">行业新闻</a></li>
            </ul>
        </div>
        <div class="tab_choice">
        	<ul id="tabmenu_tabmenu1">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=d00508f17a6bf8250950fb5d576befb5&action=lists&catid=9&num=10&order=id+DESC&return=info\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$info = $content_tag->lists(array('catid'=>'9','order'=>'id DESC','limit'=>'10',));}?>
                <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?>
                	<li><span><?php echo date('Y-m-d',$v[inputtime]);?></span><a href="<?php echo $v['url'];?>" target="_blank" title="<?php echo $v['title'];?>"<?php echo title_style($v[style]);?>><?php echo str_cut($v['title'],100);?></a></li>
                <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
<li class="tab_more"><span><a href="/news/">》》查看更多《《</a></span></li>
            </ul>
        	<ul style="display: none;" id="tabmenu_tabmenu2">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=0998e6f652449d3db02eee845cdf1032&action=lists&catid=10&num=10&order=id+DESC&return=info\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$info = $content_tag->lists(array('catid'=>'10','order'=>'id DESC','limit'=>'10',));}?>
                <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?>
                	<li><span><?php echo date('Y-m-d',$v[inputtime]);?></span><a href="<?php echo $v['url'];?>" target="_blank" title="<?php echo $v['title'];?>"<?php echo title_style($v[style]);?>><?php echo str_cut($v['title'],100);?></a></li>
                <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
<li class="tab_more"><span><a href="/industry/">》》查看更多《《</a></span></li>
            </ul>
            </div>
    </div>
    </div>
<!------------主体中间部分结束-------->
    <div class="one_right">
	<div class="sq">
    	<a href="/html/exhibition_reg/" title="申请参观" target="_blank"><img title="申请参观" alt="申请参观" src="<?php echo IMG_PATH;?>sbwexpo/images/canzhann.jpg" /></a>
        <a href="/html/exhibition_reg/" title="申请参展"><img  title="申请参展"  alt="申请参展" src="<?php echo IMG_PATH;?>sbwexpo/images/guanzhong.jpg" /></a>
        <a href="/html/zlxz/" title="资料下载"><img title="资料下载" alt="资料下载" src="<?php echo IMG_PATH;?>sbwexpo/images/xiazai.jpg" /></a>
        <a href="/MEDIANEWS" title="媒体采访" alt="媒体采访"><img src="<?php echo IMG_PATH;?>sbwexpo/images/canzhan.jpg" /></a>
       </div>
	   <div style="width:200px;margin:0 auto;margin-left:8px;text-align:center;height:305px;padding:6px;margin-left:-10px;overfllow:hidden">
<a href="#"><img src="<?php echo IMG_PATH;?>sbwexpo/images/tongqihuizhan.jpg" text-align:center /></a>
       <ol style="width:175px;text-align:left;padding-left:3px;">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=0f0b5db8a6eaeb2908553068af7d1d46&action=lists&catid=11&num=6&order=id+DESC&return=info\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$info = $content_tag->lists(array('catid'=>'11','order'=>'id DESC','limit'=>'6',));}?>
                <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?>
                	<li><a href="<?php echo $v['url'];?>" target="_blank" title="<?php echo $v['title'];?>"<?php echo title_style($v[style]);?>>»<?php echo str_cut($v['title'],38);?></a></li>
                <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
       </ol>
</div>
    </div>
</div>
</div>
<!-----------banner开始---------->
<div class="clear h8"></div>
<div class="wrap" style="height:400px;">
	<a href="http://www.zz-pi.com" target="_blank" title="中国国际博览中心"><img src="<?php echo IMG_PATH;?>sbwexpo/images/banner2.jpg" alt="中国国际博览中心" /></a>
    <div class="clear h8"></div>
	<div class="two_left">
    	<h1 style="display:block;float:left;">精彩现场</h1><span style="float:right;margin-top:16px;"><a href="/jcxc/" title="<?php echo $v['url'];?>">更多</a></span>
                <div class="section">
	<ul class="clearfix">
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2b89ee643984995dc831c20be0185ff0&action=lists&catid=36&order=listorder+ASC&thumb=1&num=4&return=info\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$info = $content_tag->lists(array('catid'=>'36','order'=>'listorder ASC','thumb'=>'1','limit'=>'4',));}?>
             <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?>
		<li>
			<div class="photo"><img src="<?php echo thumb($v[thumb],174,185);?>" width="174" height="185" /><br /><p class="txt"><?php echo $v['title'];?></p></div>
			<div class="rsp"></div>
			<div class="text"><a href="<?php echo $v['url'];?>" title="<?php echo $v['url'];?>"><h3><?php echo $v['title'];?></h3></a></div>
		</li>
          <?php $n++;}unset($n); ?>
              <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
	</ul>
</div>
<script type="text/javascript">
$(document).ready(function(){
	$(".section ul li .rsp").hide();
	
	$(".section	 ul li").hover(function(){
		$(this).find(".rsp").stop().fadeTo(500,0.5)
		$(this).find(".text").stop().animate({left:'0'}, {duration: 500})
	},function(){
		$(this).find(".rsp").stop().fadeTo(500,0)
		$(this).find(".text").stop().animate({left:'318'}, {duration: "fast"})
		$(this).find(".text").animate({left:'-318'}, {duration: 0})
	});
});
</script>
    </div>
    
  <div class="two_right" style="float:right;width:240px;">
    	<h2><a href="#">神秘扫一扫</a></h2>
<div style="width:100%;float:right"><script language="javascript" src="<?php echo APP_PATH;?>index.php?m=poster&c=index&a=show_poster&id=12"></script></div>
    </div>
</div>
    <!--------第四行结束-------->
    <div class="wrap">
    	<div class="tonglan link" style="height:110px;">
        	<h1>推荐品牌</h1>
				<div class="rollBox">
     <div class="LeftBotton" onmousedown="ISL_GoUp();" onmouseup="ISL_StopUp();" onmouseout="ISL_StopUp()"></div>
     <div class="Cont" id="ISL_Cont">
      <div class="ScrCont">
       <div id="List1">
       
        <!-- 图片列表 begin -->
		<div class="pictopp">
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"link\" data=\"op=link&tag_md5=25467993fccfe3791e8e62face723951&action=type_list&siteid=%24siteid&linktype=1&typeid=53&order=listorder+DESC&num=50&return=pic_link\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$link_tag = pc_base::load_app_class("link_tag", "link");if (method_exists($link_tag, 'type_list')) {$pic_link = $link_tag->type_list(array('siteid'=>$siteid,'linktype'=>'1','typeid'=>'53','order'=>'listorder DESC','limit'=>'50',));}?>
        <?php $n=1;if(is_array($pic_link)) foreach($pic_link AS $v) { ?>
<div class="pic">
<a href="<?php echo $v['url'];?>" title="<?php echo $v['name'];?>" target="_blank"><img src="<?php echo $v['logo'];?>" width="88" height="31" /></a>
         </div>  
        <?php $n++;}unset($n); ?>
        <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
</div>
        <!-- 图片列表 end -->
       </div>
       <div id="List2">
        <!-- 图片列表 begin -->
		<div class="pictopp">
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"link\" data=\"op=link&tag_md5=25467993fccfe3791e8e62face723951&action=type_list&siteid=%24siteid&linktype=1&typeid=53&order=listorder+DESC&num=50&return=pic_link\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$link_tag = pc_base::load_app_class("link_tag", "link");if (method_exists($link_tag, 'type_list')) {$pic_link = $link_tag->type_list(array('siteid'=>$siteid,'linktype'=>'1','typeid'=>'53','order'=>'listorder DESC','limit'=>'50',));}?>
        <?php $n=1;if(is_array($pic_link)) foreach($pic_link AS $v) { ?>
<div class="pic">
<a href="<?php echo $v['url'];?>" title="<?php echo $v['name'];?>" target="_blank"><img src="<?php echo $v['logo'];?>" width="88" height="31" /></a>
         </div>  
        <?php $n++;}unset($n); ?>
        <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
				</div>
        <!-- 图片列表 end -->
      </div>
     </div>
     <div class="RightBotton" onmousedown="ISL_GoDown();" onmouseup="ISL_StopDown();" onmouseout="ISL_StopDown()"></div>
    </div>

</div>
</div>
</div>

<div class="wrap">
	<div class="link">
	<h1>合作媒体</h1>
    <style type="text/css"> 
#scrollDiv{width:1001px;height:220px;min-height:93px;overflow:hidden} 
#scrollDiv li{float:left;width:129px;height:55px;margin:5px 6px 10px 6px;} 
</style> 

<script type="text/javascript"> 
//滚动插件 
(function($){ 
$.fn.extend({ 
Scroll:function(opt,callback){ 
//参数初始化 
if(!opt) var opt={}; 
var _this=this.eq(0).find("ul:first"); 
var lineH=_this.find("li:first").height(), //获取行高 
line=opt.line?parseInt(opt.line,10):parseInt(this.height()/lineH,10), //每次滚动的行数，默认为一屏，即父容器高度 
speed=opt.speed?parseInt(opt.speed,10):500, //卷动速度，数值越大，速度越慢（毫秒） 
timer=opt.timer?parseInt(opt.timer,10):3000; //滚动的时间间隔（毫秒） 
if(line==0) line=1; 
var upHeight=0-line*lineH; 
//滚动函数 
scrollUp=function(){ 
_this.animate({ 
marginTop:upHeight 
},speed,function(){ 
for(i=1;i<=line;i++){ 
_this.find("li:first").appendTo(_this); 
} 
_this.css({marginTop:0}); 
}); 
} 
//鼠标事件绑定 
_this.hover(function(){ 
clearInterval(timerID); 
},function(){ 
timerID=setInterval("scrollUp()",timer); 
}).mouseout(); 
} 
}) 
})(jQuery); 
$(document).ready(function(){ 
$("#scrollDiv").Scroll({line:4,speed:1,timer:3000}); 
});
</script> 

<div id="scrollDiv"> 
<ul style="margin-left:-12pz;"> 
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"link\" data=\"op=link&tag_md5=0b6e8ee1ae2e43408015a80580fbea30&action=type_list&siteid=%24siteid&linktype=1&typeid=54&order=listorder+DESC&num=100&return=pic_link\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$link_tag = pc_base::load_app_class("link_tag", "link");if (method_exists($link_tag, 'type_list')) {$pic_link = $link_tag->type_list(array('siteid'=>$siteid,'linktype'=>'1','typeid'=>'54','order'=>'listorder DESC','limit'=>'100',));}?>
        <?php $n=1;if(is_array($pic_link)) foreach($pic_link AS $v) { ?>
<li><a href="<?php echo $v['url'];?>" title="<?php echo $v['name'];?>" target="_blank"><img src="<?php echo $v['logo'];?>" width="120" height="44" /></a></li> 
        <?php $n++;}unset($n); ?>

</ul> 
</div> 
<!------友情链接结束------->
    </div>
</div>
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/global.js"></script>
</div>
<?php include template("content","footer"); ?>
<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
	<div class="aboutcon center">
		<div class="about_left left">
		<h1><p><?php echo str_cut($CATEGORYS[$catid]['catname'],13);?></p></h1>
		<ul class="classify">
			<h2>相关栏目</h2>
			<?php $j=1;?>
<?php $n=1;if(is_array(subcat($parentid))) foreach(subcat($parentid) AS $v) { ?> 
<?php if($v['type']!=0) continue;?>
<li<?php if($catid==$v[catid]) { ?> class="selected"<?php } ?>><a href="<?php echo $v['url'];?>"><b>·</b> <?php echo $v['catname'];?></a></li>
<?php $n++;}unset($n); ?>		
		</ul>
<ul class="classify gonggao">
			<h2>推荐新闻</h2>		
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=cfe1f11dbd47d85c1110689b7361b08f&action=lists&catid=9%2C10&order=id+DESC&num=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'9,10','order'=>'id DESC','limit'=>'10',));}?>
<?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
<li><a href="<?php echo $r['url'];?>" title="所在栏目：<?php echo $CATEGORYS[$r['catid']]['catname'];?>&#13;标题：<?php echo $r['title'];?>">»<?php echo str_cut($r['title'],'46');?></a></li>
<?php $n++;}unset($n); ?>
<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>			
		</ul>
		<h3><a href="/html/contact/" title="联系我们">联系我们</a></h3>
		</div>
		<div class="about_right left">
			<h2><a href="<?php echo siteurl($siteid);?>">网站首页</a> > <?php echo catpos($catid);?> 正文</h2>
			<div class="list">
			<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=5ab4b05e97fd14c3ed386604ee1a9399&action=lists&catid=%24catid&num=25&order=id+DESC&page=%24page\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$pagesize = 25;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$content_total = $content_tag->count(array('catid'=>$catid,'order'=>'id DESC','limit'=>$offset.",".$pagesize,'action'=>'lists',));$pages = pages($content_total, $page, $pagesize, $urlrule);$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>$offset.",".$pagesize,'action'=>'lists',));}?>
			<ul>
			<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
				<li><span class="right"><?php echo date('Y-m-d',$r[inputtime]);?></span>·<a href="<?php echo $r['url'];?>" target="_blank"<?php echo title_style($r[style]);?>><?php echo $r['title'];?></a></li>
			<?php if($n%5==0) { ?><li class="hr"></li><?php } ?>
			<?php $n++;}unset($n); ?>
				</ul>
			<div id="pages" class="text-c"><?php echo $pages;?></div>
			<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
			</div>
			</div>
	</div>	
</div>
<?php include template("content","footer"); ?>
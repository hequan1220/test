<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<meta name="author" content="LiuFuCai" />
<meta name="UpDate" content="2013-10-08" />
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/jquery.sgallery.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/global.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>sbwexpo/js/menu.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo CSS_PATH;?>sbwexpo/css/sbwexpo.css"/>
<link href="<?php echo CSS_PATH;?>sbwexpo/css/reset_panda.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_PATH;?>sbwexpo/css/style.css" rel="stylesheet" type="text/css" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?><?php echo $SEO['site_title'];?></title>
	<!--[if IE 6]>
<script src="<?php echo JS_PATH;?>sbwexpo/js/DD_belatedPNG.js"></script>
	<script>
	  DD_belatedPNG.fix('.nav,.tips,.about_left h1');
	</script>
	<![endif]-->
</head>
<body>
<!------------head start-------------->
<div class="head">
  <div class="wrap fff">
	<div class="tips" id="announ">
            <ul id="announ">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=0c47352bd95f85c91cea75d8803b09ef&action=lists&catid=34&num=10&order=id+DESC&return=info\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$info = $content_tag->lists(array('catid'=>'34','order'=>'id DESC','limit'=>'10',));}?>
                <?php $n=1;if(is_array($info)) foreach($info AS $v) { ?>
                	<li><a href="<?php echo $v['url'];?>" class="bright"  target="_blank" title="<?php echo $v['title'];?>"<?php echo title_style($v[style]);?>><?php echo str_cut($v['title'],100);?></a>     <span><?php echo date('Y-m-d',$v[inputtime]);?></span></li>
                <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
<script type="text/javascript">
$(function(){
	startmarquee('announ',28,1,400,4000);
})
</script>
     <div class="setup">
   		  <a href="#" id="sethomepage">设为首页</a> | 
          <a href="#" id="favorites">加入收藏</a> | 
     </div>

<div  style="clear:both" >
<script language="javascript" src="http://www.zz-pi.com/index.php?m=poster&c=index&a=show_poster&id=11"></script>
</div>
       <div id="myslidemenu">
        	<ul class="nav">
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b43f1459ac702900c8d44c91a5e796dd&action=category&catid=0&num=25&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>'0','siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'25',));}?>
            <li class="home"><a href="/">首页</a></li>
            <?php $n=1; if(is_array($data)) foreach($data AS $k => $v) { ?>
        	<li><a href="<?php echo $v['url'];?>"><?php echo $v['catname'];?></a>
                  <ul id="jquerys_blue">
                  <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=050b6fa64652ce6258bc9e7d61f5b7cc&action=category&catid=%24k&num=10&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>$k,'siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'10',));}?>
                 <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>  <li><a href="<?php echo $r['url'];?>"><?php echo $r['catname'];?></a></li> <?php $n++;}unset($n); ?>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                  </ul>
            </li>
                        <?php $n++;}unset($n); ?>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        </ul>
        </div>
    </div>
  </div>




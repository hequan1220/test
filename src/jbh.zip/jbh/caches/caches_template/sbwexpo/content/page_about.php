<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
	<div class="aboutcon center">
		<div class="about_left left">
		<h1><p><?php echo $CATEGORYS[$catid]['catname'];?></p></h1>
		<ul class="classify">
			<h2>相关栏目</h2>
  <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=46ea3926f31a5bd7e8fbefdb11306db6&action=category&catid=%24parentid&num=25&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>$parentid,'order'=>'listorder ASC','limit'=>'25',));}?>
 <ul>
 <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
   <li <?php if($catid==$r[catid]) { ?>class="selected"<?php } ?>><a href="<?php echo $r['url'];?>/"><?php echo $r['catname'];?></a></li>
 <?php $n++;}unset($n); ?>
 </ul>
 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
<ul class="classify gonggao">
			<h2>推荐新闻</h2>		
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=13b81b460bcb15900df6f741cd25fc88&action=lists&catid=102%2C159&order=id+DESC&num=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'102,159','order'=>'id DESC','limit'=>'10',));}?>
<?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
<li><a href="<?php echo $r['url'];?>" title="所在栏目：<?php echo $CATEGORYS[$r['catid']]['catname'];?>&#13;标题：<?php echo $r['title'];?>">»<?php echo str_cut($r['title'],'46');?></a></li>
<?php $n++;}unset($n); ?>
<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>			
		</ul>
		<h3><a href="/html/contact/" title="联系我们">联系我们</a></h3>
		</div>
		<div class="about_right left">
			<h2><a href="<?php echo siteurl($siteid);?>">网站首页</a> > <?php echo catpos($catid);?> 正文</h2>
			<div class="info">
				<div class="info_title"><h4><?php echo $title;?></h4></div>
				<div class="info_time"></div>
				<?php if($description) { ?><div class="info_description">核心提示：<?php echo $description;?></div><?php } ?>
				<div class="info_content">
				<?php echo $content;?>
				</div>
				<div id="pages"><?php echo $pages;?></div>
				<div class="info_service">
						<span class="favorites"><a href="javascript:window.external.addFavorite(window.location.href,'新闻 ');">加入收藏</a></span>
						<span class="print"><a href="javascript:window.print();">打印本页</a></span>
						<span class="close"><a href="javascript:window.close();">关闭窗口</a></span>
						<span class="top"><a href="javascript:window.scrollTo(0,0);">返回顶部</a></span>
				</div>
			</div>
		</div>
	</div>	
</div>
</div>
<?php include template("content","footer"); ?>
<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><div class="clear h8"></div>
<div class="bottom">
	<div class="copyright">
<P>河南中原国际博览中心有限公司  
地址：郑州市郑汴路96号 
网址：www.zz-pi.com</p>
<p>电话：0371-66759136 66759250 66759071
客服：QQ:1061791595
</p>


    豫ICP备0914132号-4  版权所有：河南中原国际博览中心有限公司<Br>

        </div>
</div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"16"},"slide":{"type":"slide","bdImg":"2","bdPos":"right","bdTop":"310"},"image":{"viewList":["qzone","tsina","tqq","renren","t163"],"viewText":"分享到：","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","t163"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=86835285.js?cdnversion='+~(-new Date()/36e5)];</script>

<link href="http://i.bsie.cn/kf/css/service.css" type="text/css" rel="stylesheet" />


<div id="floatTips" style="position:fixed;_position:absolute;padding: 3px;top: 300px;right: 155px;width: 30px;height: 300px;z-index:999;display:;">
  <div id="serviceCenter">
    <div class="sc_header"> <font style="float:left;margin:6px 0 0 10px">客服中心</font> <a href="javascript:;" title="关闭" style="width:15px;height:16px;display:block;margin:7px 0 0 45px;float:left;" onclick="document.getElementById('floatTips').style.display='none'"></a> </div>
    <ul class="sc_ul" id="sc_ul">
      <li id="sc_0">
        <h3><font class="li_down" id="sc_pre"></font><font style="float:left;margin:8px 0 0 5px;font-weight:600;">参展咨询</font></h3>
        <div style="display:block;height:124px;" id="sc_yes_sale"> <font style="font-size:12px;font-weight:700;margin:10px 0 0 10px;float:left;height:30px;width:122px;line-height:23px;"><font id="sc_name" style="float:left;"></font>丁经理:</font> <font style="margin-left:16px;float:left;line-height:17px;margin-top:1px;letter-spacing:0px"> &nbsp;&nbsp;QQ：<font id="sc_qq">1061791595</font><br>
          总机：0371-86503691<br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font style="letter-spacing:1px;text-indent:2em;"><font id="sc_tel"></font></font><br>
           <font id="sc_phone"> &nbsp;</font></font> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=1061791595&site=qq&menu=yes"  style="float:right;cursor:pointer;position:relative;top:-99px;left:-7px;"  ><img src='http://i.bsie.cn/kf/images/counseling_style_52.png' /></a> <a href="###" style=""></a><span class="sc_intro" style="margin-top:-35px;"><font style="margin:4px 0 0 10px;float:left;">在线时间8:30-18:00</font></span> </div>
      </li>
      <li id="sc_1" class="line_top">
        <h3><font class="li_left" id="sc_support"></font><font style="float:left;margin:8px 0 0 5px;font-weight:700;">参观咨询</font></h3>
        <div id="sc_support_div" style="height:125px"> <font style="font-size:12px;font-weight:700;margin:10px 0 0 10px;float:left;height:30px;width:122px;line-height:23px;"><font id="sc_name" style="float:left;"></font>王经理:</font> <font style="margin-left:16px;float:left;line-height:17px;margin-top:1px;letter-spacing:0px"> &nbsp;&nbsp;QQ：<font id="sc_qq">1246701854</font><br>
          总机：0371-66759157 <br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font style="letter-spacing:1px;text-indent:2em;"><font id="sc_tel"></font></font><br>
           <font id="sc_phone"> &nbsp;</font></font> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=1246701854&site=qq&menu=yes"  style="float:right;cursor:pointer;position:relative;top:-99px;left:-7px;"  ><img src='http://i.bsie.cn/kf/images/counseling_style_52.png' /></a> <a href="###" style=""></a><span class="sc_intro" style="margin-top:-35px;"><font style="margin:4px 0 0 10px;float:left;">在线时间8:30-18:00</font></span> </div>
      </li>
      </li>
    </ul>
  </div>
</div>




<!--<div id="floatTips" style="position:fixed;_position:absolute;padding: 3px;top:540px;right:180px;width: 30px;height: 300px;z-index:999;display:;">
<a href="http://www.sbwexpo.com/html/donwload/Purchaser-assembly/"><img src="http://i.bsie.cn/kf/images/shui1.jpg"  style="width:210px;height:150px;"/></a>

</div>-->










<script>
var scLiObjs=document.getElementById("sc_ul").getElementsByTagName("li");
for(var i = 0 ; i<scLiObjs.length;i++){
	scLiObjs[i].onclick=function (){
		var liObjs = this.parentNode.getElementsByTagName("li"); //获取父UL节点 LI标签们
		for (var j=0;j<liObjs.length;j++){
			if (liObjs[j]==this){
				this.getElementsByTagName("font")[0].className = "li_down";
				this.getElementsByTagName("div")[0].style.display="block";
			}else{
				liObjs[j].getElementsByTagName("font")[0].className = "li_left";
				liObjs[j].getElementsByTagName("div")[0].style.display="none";
			}
		}
		
	}
}

  
 
	//<![CDATA[  
	var tips; var theTop = 96/*这是默认高度,越大越往下*/; var old = theTop;
	function initFloatTips() {
		tips = document.getElementById('floatTips');
		moveTips();
	};
	function moveTips() {
		var tt = 50;
		if (window.innerHeight) {
			pos = window.pageYOffset
		}
		else if (document.documentElement && document.documentElement.scrollTop) {
			pos = document.documentElement.scrollTop
		}
		else if (document.body) {
			pos = document.body.scrollTop;
		}
		pos = pos - tips.offsetTop + theTop;
		pos = tips.offsetTop + pos / 10;
		if (pos < theTop) pos = theTop;
		if (pos != old) {
			tips.style.top = pos + "px";
			tt = 10;
		}
		old = pos;
		setTimeout(moveTips, tt);
	}

	//!]]> 
	if(navigator.appVersion.indexOf("MSIE 6")>-1){
	var tmptips = document.getElementById('floatTips')
	//tmptips.style.cssText="display:absolute;top:10px;"
	
		initFloatTips()
	}
	
	slideAd('ZhujiwuTopAd',8); //控制顶部浮动广告
	
</script>



</body>
</html>